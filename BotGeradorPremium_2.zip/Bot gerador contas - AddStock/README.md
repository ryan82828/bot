# Bot Discord
BOT Discord is a project of a bot programmed to offer help to the moderators of the servers!
Bot is currently in v13 version

## Installation

Requires node at version 16.15.1 lts or higher!

``````bash
git clone https://github.com/Daniel-Developement/BOT-Discord.git
cd Leinad-Bot
npm i discord.js
``````
